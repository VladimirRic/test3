@extends('layouts.master')

@section('title', 'Приветствуем')

@section('content')
    <h1>Приветствуем</h1>
@endsection