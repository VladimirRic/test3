@extends('layouts.master')

@section('title', 'Приветствуем')

@section('content')
    <p>This is my body content.</p>
@endsection